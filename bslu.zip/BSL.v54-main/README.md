# BSL.v54
C Sharp Brawl Stars server emulator for version 54

## How to play: ##

### Server ###
1: Download the server and extract it: https://github.com/LkPrtctrd/BSL.v54/archive/refs/heads/master.zip

2: Open terminal on your computer and go to server directory.

3: Install .NET 8 and type "cd BSL.v54 && dotnet run" (or use programs like visual studio)

4: Follow client instructions

### Android Client ###
1: [Download the APK here](https://mega.nz/file/TYdUUCbR#dYGTwHkCa7-zAdx9a-1iJIDUk7Dqo5c-494WbXPgr0g)

2: Change redirectHost (also redirectPort and offlineBattles if you need it) in the frida config (lib/arm64-v8a/libBSL.c.so)

3: Enjoy playing BSL.v54!

## Screenshots ##
![BSL.v54](./Screenshots/menu.png)
