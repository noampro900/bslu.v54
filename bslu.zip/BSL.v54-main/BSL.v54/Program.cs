﻿using BSL.v54.Core;
namespace BSL.v54;

public static class Program
{
    public static void Main(string[] args)
    {
        new LaserTcpCentralGateway(9339).Start();

        for (;;) ;
    }
}