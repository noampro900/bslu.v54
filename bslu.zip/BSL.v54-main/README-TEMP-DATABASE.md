# Temporary player database

The server creates `Data/TemporaryPlayers.json` in the process working directory.
A record is created on login and persists between restarts.

- `BrawlPassOwned` defaults to `false`.
- `ClaimedBrawlPassLevels` stores `season:level` keys to prevent repeat claims.
- Command 517 is decoded and rejected unless the account's `BrawlPassOwned` flag is true.
- This is a lightweight JSON development store, not production-grade storage.
- Reward contents are not yet granted: LRBS's reward tables and delivery-message pipeline
  still need to be ported before a successful claim can show actual items in the game.

For local testing only, stop the server and edit the relevant player's JSON record to set
`"BrawlPassOwned": true`. Do not expose this file or let clients set that property.
