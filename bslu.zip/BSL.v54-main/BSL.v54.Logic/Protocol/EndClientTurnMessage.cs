﻿using BSL.v54.Logic.Commands;
using BSL.v54.TitanEngine.DataS;

namespace BSL.v54.Logic.Protocol;

/// <summary>Client message 14102: a batch of logic commands.</summary>
public sealed class EndClientTurnMessage : PiranhaMessage
{
    private readonly List<ILogicCommand> _commands = new();
    public int Tick { get; private set; }
    public int Checksum { get; private set; }
    public IReadOnlyList<ILogicCommand> Commands => _commands;

    public override int GetMessageType() => 14102;
    public override int GetServiceNodeType() => 1;

    public override void Decode()
    {
        base.Decode();
        _ = ByteStream.ReadBoolean(); // useChecksum
        Tick = ByteStream.ReadVInt();
        Checksum = ByteStream.ReadVInt();
        var count = ByteStream.ReadVInt();
        if (count < 0 || count > 256)
            throw new InvalidDataException($"Invalid command count: {count}");

        for (var i = 0; i < count; i++)
        {
            var id = ByteStream.ReadVInt();

            // LRBS-54 names command 536 as PurchaseBrawlpassProgressCommand,
            // but does not include its wire decoder. When it is the final
            // command in this EndClientTurn packet, safely ignore its remaining
            // payload rather than disconnecting the client. Do not do this if
            // more commands follow, because their boundaries would be unknown.
            if (id == 536)
            {
                if (i != count - 1)
                    throw new InvalidDataException(
                        "Logic command 536 is unsupported when followed by other commands in the same packet.");

                Console.WriteLine(
                    "Ignoring unsupported trailing logic command 536 (PurchaseBrawlpassProgressCommand).");

                ByteStream.SetOffset(ByteStream.GetLength());
                break;
            }

            if (!LogicCommandManager.TryCreate(id, out var command) || command is null)
                throw new InvalidDataException(
                    $"Unsupported logic command {id}. Its payload cannot be skipped safely without its v54 decoder.");

            command.Decode(this);
            _commands.Add(command);
        }
    }

    public void Execute(CommandContext context)
    {
        foreach (var command in _commands)
        {
            Console.WriteLine($"Executing client logic command: {command.Name} ({command.CommandType})");
            command.Execute(context);
        }
    }
}
