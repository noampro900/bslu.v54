using BSL.v54.Logic.Commands;

namespace BSL.v54.Logic.Protocol.Laser.S;

/// <summary>
/// Server message 24111 carrying one LogicServerCommand.
/// </summary>
public sealed class AvailableServerCommandMessage : PiranhaMessage
{
    private readonly IReadOnlyList<LogicDeliveryItem> _boxes;
    private readonly int _rewardTrackType;
    private readonly int _rewardForRank;
    private readonly int _brawlPassSeason;

    // Required by the message factory.
    public AvailableServerCommandMessage()
        : this(Array.Empty<LogicDeliveryItem>(), 0, 0, 24)
    {
    }

    public AvailableServerCommandMessage(
        IReadOnlyList<LogicDeliveryItem> boxes,
        int rewardTrackType,
        int rewardForRank,
        int brawlPassSeason)
    {
        _boxes = boxes ?? throw new ArgumentNullException(nameof(boxes));
        _rewardTrackType = rewardTrackType;
        _rewardForRank = rewardForRank;
        _brawlPassSeason = brawlPassSeason;
    }

    public override void Encode()
    {
        base.Encode();

        ByteStream.WriteVInt(LogicGiveDeliveryItemsCommand.CommandType);
        LogicGiveDeliveryItemsCommand.Encode(
            ByteStream,
            _boxes,
            _rewardTrackType,
            _rewardForRank,
            _brawlPassSeason);
    }

    public override int GetMessageType() => 24111;
    public override int GetServiceNodeType() => 9;
}
