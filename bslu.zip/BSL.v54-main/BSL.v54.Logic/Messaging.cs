
using System;
using System.Collections.Generic;
using System.Linq;
using BSL.v54.Logic.OknoLayer;
using BSL.v54.Logic.Protocol;
using BSL.v54.Logic.Protocol.Laser.S;
using BSL.v54.TitanEngine.Blake;
using BSL.v54.TitanEngine.DataS;
using BSL.v54.TitanEngine.NaCl;
using BSL.v54.TitanEngine.Pepp;
using BSL.v54.TitanEngine.Pepp.Crypto;
using NetCoreServer;
using Buffer = System.Buffer;

namespace BSL.v54.Logic;

public class Messaging
{
    private readonly byte[] _secretKey;
    private readonly byte[] _sessionToken;
    private readonly byte[] _sNonce;

    private byte[] _clientPk = null!;
    private byte[] _rNonce = null!;

    private PepperEncrypter _decryptStream = null!;
    private PepperEncrypter _encryptStream = null!;

    private int _pepperState = 1;

    private MessageManager? _messageManager;

    private readonly List<byte> _receiveBuffer = new();
    private readonly object _receiveLock = new();
    private readonly object _sendLock = new();

    private const int HeaderSize = 7;
    private const int MaxFrameSize = 2048;

    public TcpSession TcpSessionInst { get; set; }

    public Messaging(TcpSession session)
    {
        TcpSessionInst = session;

        _sessionToken = new byte[24];
        _secretKey = new byte[32];
        _sNonce = new byte[24];

        TweetNaCl.RandomBytes(_sessionToken);
        TweetNaCl.RandomBytes(_secretKey);
        TweetNaCl.RandomBytes(_sNonce);

        SetState(2);
    }

    public int NextMessage(
        byte[] buffer,
        long offset,
        long size,
        out (int, int, int) header)
    {
        header = (-600, 0, 0);

        if (buffer == null ||
            offset < 0 ||
            size < 0 ||
            offset > buffer.Length ||
            size > buffer.Length - offset)
        {
            return -600;
        }

        lock (_receiveLock)
        {
            _receiveBuffer.AddRange(
                buffer.AsSpan((int)offset, (int)size).ToArray()
            );

            int lastResult = 0;

            while (_receiveBuffer.Count >= HeaderSize)
            {
                byte[] headerBytes = _receiveBuffer
                    .Take(HeaderSize)
                    .ToArray();

                var currentHeader = ReadHeader(headerBytes);

                int messageType = currentHeader.Item1;
                int messageLength = currentHeader.Item2;
                int messageVersion = currentHeader.Item3;

                int frameLength = HeaderSize + messageLength;

                if (frameLength > MaxFrameSize)
                {
                    Console.WriteLine(
                        $"Invalid packet length: {messageLength}"
                    );

                    _receiveBuffer.Clear();
                    header = (-601, 0, 0);

                    return -601;
                }

                if (_receiveBuffer.Count < frameLength)
                    break;

                byte[] payload = _receiveBuffer
                    .Skip(HeaderSize)
                    .Take(messageLength)
                    .ToArray();

                _receiveBuffer.RemoveRange(0, frameLength);

                header = currentHeader;

                Console.WriteLine(
                    $"TCP packet: Type={messageType}, " +
                    $"Length={messageLength}, " +
                    $"Version={messageVersion}"
                );

                lastResult = ReadNewMessage(
                    messageType,
                    messageLength,
                    messageVersion,
                    payload
                );

                if (lastResult < 0)
                {
                    Console.WriteLine(
                        $"Message processing error: {lastResult}"
                    );

                    _receiveBuffer.Clear();
                    return lastResult;
                }
            }

            return lastResult;
        }
    }

    public int ReadNewMessage(
        int type,
        int length,
        int version,
        byte[] payload)
    {
        if (payload == null || length != payload.Length)
            return -601;

        switch (_pepperState)
        {
            case 2:
            {
                if (type != 10100)
                    return -602;

                SetState(3);
                break;
            }

            case 3:
            {
                if (type != 10101)
                    return -603;

                byte[] loginPayload = HandlePepperLogin(payload);

                if (loginPayload == null)
                    return -604;

                payload = loginPayload;
                length = payload.Length;

                break;
            }

            case 5:
            {
                int overhead =
                    _decryptStream.GetEncryptionOverhead();

                if (length < overhead)
                {
                    Console.WriteLine(
                        $"Encrypted packet too short: {length}"
                    );

                    return -605;
                }

                byte[] decryptedPayload =
                    new byte[length - overhead];

                int result;

                try
                {
                    result = _decryptStream.Decrypt(
                        payload,
                        decryptedPayload,
                        length
                    );
                }
                catch (Exception ex)
                {
                    Console.WriteLine(
                        $"Decryption exception for {type}: {ex}"
                    );

                    return -605;
                }

                if (result != 0)
                {
                    Console.WriteLine(
                        $"Decryption failed: Type={type}, " +
                        $"Length={length}, Result={result}"
                    );

                    return -605;
                }

                payload = decryptedPayload;
                length = payload.Length;

                break;
            }

            default:
                return -607;
        }

        try
        {
            var piranhaMessage =
                LogicLaserMessageFactory.CreateMessageByType(type);

            if (piranhaMessage == null)
            {
                Console.WriteLine(
                    $"Unknown message received: {type}"
                );

                return 0;
            }

            if (length > 0)
            {
                piranhaMessage.ByteStream.SetByteArray(
                    payload,
                    payload.Length
                );

                piranhaMessage.Decode();
            }

            Console.WriteLine(
                $"New message received: {type}."
            );

            if (type == 10100)
            {
                Send(new ServerHelloMessage());
                return 0;
            }

            if (_messageManager == null)
                return -666;

            return _messageManager.ReceiveMessage(
                piranhaMessage
            );
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"Message processing failed: {type}"
            );

            Console.WriteLine(ex);

            return -606;
        }
    }

    public byte[] HandlePepperLogin(byte[] payload)
    {
        try
        {
            if (payload == null || payload.Length < 48)
                return null!;

            _clientPk = payload
                .Take(32)
                .ToArray();

            var hasher = new Blake2BHasher();

            hasher.Update(_clientPk);
            hasher.Update(PepperKey.ServerPublicKey);

            byte[] decrypted = TweetNaCl.CryptoBoxOpen(
                payload.Skip(32).ToArray(),
                hasher.Finish(),
                PepperKey.ServerPublicKey,
                PepperKey.ClientSecretKey
            );

            if (decrypted == null || decrypted.Length < 48)
                return null!;

            if (!decrypted
                    .Take(24)
                    .SequenceEqual(_sessionToken))
            {
                Console.WriteLine(
                    "Pepper login token mismatch."
                );

                return null!;
            }

            _rNonce = decrypted
                .Skip(24)
                .Take(24)
                .ToArray();

            SetState(4);

            _messageManager = new MessageManager(this);

            return decrypted
                .Skip(48)
                .ToArray();
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"Pepper login failed: {ex}"
            );

            return null!;
        }
    }

    public byte[] SendPepperLoginResponse(byte[] payload)
    {
        if (_rNonce == null || _rNonce.Length != 24)
            throw new InvalidOperationException(
                "Client nonce is not initialized."
            );

        var packet = new byte[payload.Length + 56];

        Buffer.BlockCopy(
            _sNonce, 0,
            packet, 0, 24
        );

        Buffer.BlockCopy(
            _secretKey, 0,
            packet, 24, 32
        );

        Buffer.BlockCopy(
            payload, 0,
            packet, 56, payload.Length
        );

        var hasher = new Blake2BHasher();

        hasher.Update(_rNonce);
        hasher.Update(_clientPk);
        hasher.Update(PepperKey.ServerPublicKey);

        byte[] encrypted = TweetNaCl.CryptoBox(
            packet,
            hasher.Finish(),
            PepperKey.ServerPublicKey,
            PepperKey.ClientSecretKey
        );

        _decryptStream = new PepperEncrypter(
            _secretKey,
            (byte[])_rNonce.Clone()
        );

        _encryptStream = new PepperEncrypter(
            _secretKey,
            (byte[])_sNonce.Clone()
        );

        SetState(5);

        return encrypted;
    }

    public void Send(PiranhaMessage piranhaMessage)
    {
        if (piranhaMessage == null)
            return;

        if (_pepperState == 3 &&
            piranhaMessage is ServerHelloMessage hello)
        {
            hello.SetServerHelloToken(_sessionToken);
        }

        EncryptAndWrite(piranhaMessage);
    }

    public int EncryptAndWrite(PiranhaMessage piranhaMessage)
    {
        lock (_sendLock)
        {
            if (piranhaMessage == null)
                return -1;

            if (!piranhaMessage.IsServerToClientMessage())
                return -1;

            if (piranhaMessage.GetEncodingLength() == 0)
                piranhaMessage.Encode();

            int encodingLength =
                piranhaMessage.GetEncodingLength();

            if (encodingLength < 0)
                return -1;

            byte[] payload = new byte[encodingLength];

            Buffer.BlockCopy(
                piranhaMessage.GetMessageBytes(),
                0,
                payload,
                0,
                payload.Length
            );

            try
            {
                switch (_pepperState)
                {
                    case 3:
                        break;

                    case 4:
                        payload = SendPepperLoginResponse(payload);
                        break;

                    case 5:
                    {
                        int overhead =
                            _encryptStream.GetEncryptionOverhead();

                        byte[] encryptedPayload =
                            new byte[payload.Length + overhead];

                        int result = _encryptStream.Encrypt(
                            payload,
                            encryptedPayload,
                            payload.Length
                        );

                        if (result != 0)
                        {
                            Console.WriteLine(
                                $"Encryption failed: {result}"
                            );

                            return -1;
                        }

                        payload = encryptedPayload;
                        break;
                    }

                    default:
                        return -1;
                }

                if (payload.Length + HeaderSize > MaxFrameSize)
                {
                    Console.WriteLine(
                        $"Outgoing packet too large: {payload.Length}"
                    );

                    return -1;
                }

                byte[] message = WriteHeader(
                    payload,
                    piranhaMessage.GetMessageType(),
                    piranhaMessage.GetMessageVersion()
                );

                Buffer.BlockCopy(
                    payload,
                    0,
                    message,
                    HeaderSize,
                    payload.Length
                );

                TcpSessionInst.SendAsync(message);

                Console.WriteLine(
                    $"New message has been sent: " +
                    $"{piranhaMessage.GetMessageType()}."
                );

                return 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine(
                    $"Failed to send message: {ex}"
                );

                return -1;
            }
        }
    }

    public static (int, int, int) ReadHeader(
        byte[] headerBuffer)
    {
        if (headerBuffer == null ||
            headerBuffer.Length < HeaderSize)
        {
            throw new ArgumentException(
                "Message header must contain 7 bytes."
            );
        }

        int type =
            (headerBuffer[0] << 8) |
            headerBuffer[1];

        int length =
            (headerBuffer[2] << 16) |
            (headerBuffer[3] << 8) |
            headerBuffer[4];

        int version =
            (headerBuffer[5] << 8) |
            headerBuffer[6];

        return (type, length, version);
    }

    public static byte[] WriteHeader(
        byte[] payload,
        int type,
        int version)
    {
        if (payload == null)
            throw new ArgumentNullException(nameof(payload));

        if (type < 0 || type > ushort.MaxValue)
            throw new ArgumentOutOfRangeException(nameof(type));

        if (version < 0 || version > ushort.MaxValue)
            throw new ArgumentOutOfRangeException(nameof(version));

        if (payload.Length > 0xFFFFFF)
            throw new ArgumentOutOfRangeException(nameof(payload));

        byte[] final = new byte[payload.Length + HeaderSize];

        final[0] = (byte)(type >> 8);
        final[1] = (byte)type;

        final[2] = (byte)(payload.Length >> 16);
        final[3] = (byte)(payload.Length >> 8);
        final[4] = (byte)payload.Length;

        final[5] = (byte)(version >> 8);
        final[6] = (byte)version;

        return final;
    }

    public void SetState(int state)
    {
        _pepperState = state;
    }
}
