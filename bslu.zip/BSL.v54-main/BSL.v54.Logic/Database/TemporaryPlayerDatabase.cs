﻿using System.Collections.Concurrent;
using System.Text.Json;

namespace BSL.v54.Logic.Database;

/// <summary>
/// Lightweight local development database. Data is persisted as JSON so the
/// project does not require an external database package. Replace with a real
/// database provider before production use.
/// </summary>
public sealed class TemporaryPlayerDatabase
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };
    private static readonly ConcurrentDictionary<long, object> Locks = new();
    private readonly string _filePath;
    private readonly object _fileLock = new();

    public TemporaryPlayerDatabase(string? filePath = null)
    {
        _filePath = Path.GetFullPath(filePath ?? Path.Combine("Data", "TemporaryPlayers.json"));
        Directory.CreateDirectory(Path.GetDirectoryName(_filePath)!);
        if (!File.Exists(_filePath))
            File.WriteAllText(_filePath, "{}");
    }

    public TemporaryPlayerRecord GetOrCreate(long accountId, string? passToken = null)
    {
        if (accountId <= 0)
            throw new ArgumentOutOfRangeException(nameof(accountId), "A positive account ID is required.");
        lock (_fileLock)
        {
            var all = ReadAll();
            if (!all.TryGetValue(accountId.ToString(), out var record))
            {
                record = new TemporaryPlayerRecord
                {
                    AccountId = accountId,
                    PassToken = passToken ?? string.Empty,
                    CreatedUtc = DateTimeOffset.UtcNow
                };
                all[accountId.ToString()] = record;
                WriteAll(all);
            }
            else if (!string.IsNullOrWhiteSpace(passToken) && string.IsNullOrEmpty(record.PassToken))
            {
                record.PassToken = passToken;
                WriteAll(all);
            }
            return record;
        }
    }

    public TemporaryPlayerRecord? Get(long accountId)
    {
        lock (_fileLock)
        {
            var all = ReadAll();
            return all.TryGetValue(accountId.ToString(), out var record) ? record : null;
        }
    }

    public bool TryClaimBrawlPassLevel(
        long accountId, int season, int trackType, int level, int coinRewardAmount, out string result)
    {
        lock (_fileLock)
        {
            var all = ReadAll();
            if (!all.TryGetValue(accountId.ToString(), out var record))
            {
                result = "Player record does not exist.";
                return false;
            }
            if (!record.BrawlPassOwned)
            {
                result = "Brawl Pass ownership is required.";
                return false;
            }
            if (season < 0 || trackType < 0 || level < 0 || level > 100 || coinRewardAmount <= 0)
            {
                result = "Invalid Brawl Pass season, track, level, or reward amount.";
                return false;
            }

            // Include the track in the claim key so claiming the same level
            // on one track does not block another Brawl Pass track.
            var key = $"{season}:{trackType}:{level}";
            if (record.CoinRewardedBrawlPassLevels.Contains(key))
            {
                result = "This Brawl Pass level's coin reward has already been credited.";
                return false;
            }

            // Older builds recorded the claim without crediting its coins.
            // Credit those existing claims once, without allowing repeat payouts.
            var wasPreviouslyClaimed = record.ClaimedBrawlPassLevels.Contains(key);
            record.ClaimedBrawlPassLevels.Add(key);
            record.CoinRewardedBrawlPassLevels.Add(key);
            record.Coins = checked(record.Coins + coinRewardAmount);
            record.UpdatedUtc = DateTimeOffset.UtcNow;
            WriteAll(all);

            result = wasPreviouslyClaimed
                ? $"Previously recorded claim credited with {coinRewardAmount} coins."
                : $"Brawl Pass claim recorded and {coinRewardAmount} coins credited.";
            return true;
        }
    }

    /// <summary>
    /// Saves the Brawl Pass delivery-track fields used by server command 203.
    /// LRBS-54 sets RewardTrackType to the claimed track and RewardForRank to
    /// 2 + claimed level before sending AvailableServerCommandMessage.
    /// </summary>
    public bool SetBrawlPassDeliveryState(
        long accountId, int rewardTrackType, int rewardForRank, int season)
    {
        lock (_fileLock)
        {
            var all = ReadAll();
            if (!all.TryGetValue(accountId.ToString(), out var record))
                return false;

            record.RewardTrackType = rewardTrackType;
            record.RewardForRank = rewardForRank;
            record.BrawlPassSeason = season;
            record.UpdatedUtc = DateTimeOffset.UtcNow;
            WriteAll(all);
            return true;
        }
    }

    // Intended for local development/testing. Set this through the JSON file
    // or an authenticated pass-purchase flow; never trust a client-supplied flag.
    public bool SetBrawlPassOwnership(long accountId, bool owned)
    {
        lock (_fileLock)
        {
            var all = ReadAll();
            if (!all.TryGetValue(accountId.ToString(), out var record)) return false;
            record.BrawlPassOwned = owned;
            record.UpdatedUtc = DateTimeOffset.UtcNow;
            WriteAll(all);
            return true;
        }
    }

    private Dictionary<string, TemporaryPlayerRecord> ReadAll()
    {
        try
        {
            return JsonSerializer.Deserialize<Dictionary<string, TemporaryPlayerRecord>>(
                       File.ReadAllText(_filePath), JsonOptions)
                   ?? new Dictionary<string, TemporaryPlayerRecord>();
        }
        catch (JsonException)
        {
            var backup = _filePath + ".corrupt-" + DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            File.Copy(_filePath, backup, true);
            return new Dictionary<string, TemporaryPlayerRecord>();
        }
    }

    private void WriteAll(Dictionary<string, TemporaryPlayerRecord> all)
    {
        var temp = _filePath + ".tmp";
        File.WriteAllText(temp, JsonSerializer.Serialize(all, JsonOptions));
        File.Move(temp, _filePath, true);
    }
}

public sealed class TemporaryPlayerRecord
{
    public long AccountId { get; set; }
    public string PassToken { get; set; } = string.Empty;
    public bool BrawlPassOwned { get; set; } = true;
    // The current hardcoded home data starts players with 1,337 coins.
    // Existing JSON records without this property retain this initializer.
    public int Coins { get; set; } = 1337;
    public int RewardTrackType { get; set; } = 0;
    public int RewardForRank { get; set; } = 0;
    public int BrawlPassSeason { get; set; } = 24;
    public HashSet<string> ClaimedBrawlPassLevels { get; set; } = new();
    public HashSet<string> CoinRewardedBrawlPassLevels { get; set; } = new();
    public DateTimeOffset CreatedUtc { get; set; }
    public DateTimeOffset UpdatedUtc { get; set; }
}
