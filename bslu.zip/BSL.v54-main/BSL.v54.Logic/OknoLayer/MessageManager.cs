﻿using BSL.v54.Logic.Database;
using BSL.v54.Logic.Protocol;
using BSL.v54.Logic.Protocol.Laser.C;
using BSL.v54.Logic.Protocol.Laser.S;
using BSL.v54.Logic.Commands;

namespace BSL.v54.Logic.OknoLayer;

public class MessageManager(Messaging messaging)
{
    private readonly TemporaryPlayerDatabase PlayerDatabase = new();
    private long _accountId;
    public int ReceiveMessage(PiranhaMessage piranhaMessage)
    {
        return piranhaMessage.GetMessageType() switch
        {
            10101 => LogicMessageReceived((LoginMessage)piranhaMessage),
            14102 => EndClientTurnReceived((EndClientTurnMessage)piranhaMessage),
            _ => 1
        };
    }

    private int EndClientTurnReceived(EndClientTurnMessage message)
    {
        try
        {
            message.Execute(new CommandContext(messaging, _accountId, PlayerDatabase));
            return 1;
        }
        catch (Exception exception)
        {
            Console.WriteLine($"Failed to process EndClientTurn command batch: {exception}");
            return -1;
        }
    }

    private int LogicMessageReceived(LoginMessage loginMessage)
    {
        if (loginMessage.ClientMajorVersion is not 54) return -1488;
        // Some clients may send a null pass token. Normalize it before
        // hashing or storing it so login cannot fail with ArgumentNullException.
        var passToken = loginMessage.PassToken ?? string.Empty;

        _accountId = loginMessage.AccountId;
        if (_accountId <= 0)
            _accountId = Math.Abs((long)StringComparer.Ordinal.GetHashCode(passToken)) + 1;

        var playerRecord = PlayerDatabase.GetOrCreate(_accountId, passToken);
        messaging.Send(new LoginOkMessage());
        messaging.Send(new OwnHomeDataMessage(playerRecord.Coins));
        
        return 1;
    }
}