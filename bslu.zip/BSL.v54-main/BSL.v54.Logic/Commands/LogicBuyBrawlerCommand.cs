using BSL.v54.Logic.Protocol;
using BSL.v54.TitanEngine.DataS.HelpsLogic;

namespace BSL.v54.Logic.Commands;

/// <summary>
/// v54 command 560. This ports the command's wire decoder from LRBS-54.
/// The state-changing purchase implementation requires the LRBS player/database
/// model and is intentionally not simulated here.
/// </summary>
public sealed class LogicBuyBrawlerCommand : ILogicCommand
{
    public int CommandType => 560;
    public string Name => "LogicBuyBrawlerCommand";
    public int[] BrawlerReference { get; private set; } = [0];

    public void Decode(PiranhaMessage message)
    {
        BrawlerReference = ByteStreamHelper.ReadDataReference(message.ByteStream);
        if (BrawlerReference.Length != 2)
            throw new InvalidDataException("Command 560 did not contain a valid brawler reference.");
    }

    public void Execute(CommandContext context)
    {
        Console.WriteLine($"Received {Name} for brawler reference [{BrawlerReference[0]}, {BrawlerReference[1]}]. " +
                          "The player-state purchase handler has not yet been ported.");
    }
}
