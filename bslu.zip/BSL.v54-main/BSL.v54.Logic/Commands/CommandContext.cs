using BSL.v54.Logic;
using BSL.v54.Logic.Database;

namespace BSL.v54.Logic.Commands;

public sealed class CommandContext(Messaging messaging, long accountId, TemporaryPlayerDatabase database)
{
    public Messaging Messaging { get; } = messaging;
    public long AccountId { get; } = accountId;
    public TemporaryPlayerDatabase Database { get; } = database;
}
