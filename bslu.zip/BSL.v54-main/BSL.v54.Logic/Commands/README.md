# Logic Delivery Item reward rule

The LRBS v54 reference maps coin rewards to `RewardID = 7`. Its delivery
reward construction appears in the mastery-claim and rank-up reward
command handlers.

`DeliveryRewardPolicy.Apply(item)` preserves non-coin rewards and replaces
any existing coin reward(s) with exactly one `RewardID = 7`, `Amount = 1000`
entry. If the delivery item did not contain a coin entry, it adds one.

The current BSL.v54 project does not yet contain LRBS's gameplay command
dispatch / delivery-item serialization pipeline. Call this policy at the
point where that pipeline constructs or serializes each Logic Delivery
Item. It is intentionally isolated so the rule is applied consistently
rather than patching individual reward-generation branches.
