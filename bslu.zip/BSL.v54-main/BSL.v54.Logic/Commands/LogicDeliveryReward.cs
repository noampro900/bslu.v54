﻿namespace BSL.v54.Logic.Commands;

/// <summary>
/// Reward entry used by Logic Delivery Items.
/// RewardId 7 is the coin resource in this BSL v54 project.
/// </summary>
public sealed record LogicDeliveryReward(int RewardId, int Amount, int DataClass = 0, int DataInstance = 0);

/// <summary>
/// A delivery item and its rewards.
/// </summary>
public sealed record LogicDeliveryItem(int Type, IReadOnlyList<LogicDeliveryReward> Items)
{
    /// <summary>
    /// Applies the LRBS v54 coin rule: every delivery item contains one
    /// 1,000-coin reward, irrespective of its other rewards.
    /// Existing coin entries are replaced; non-coin rewards are preserved.
    /// </summary>
    public LogicDeliveryItem WithGuaranteedCoins()
    {
        var rewards = Items
            .Where(reward => reward.RewardId != DeliveryRewardPolicy.CoinRewardId)
            .ToList();

        rewards.Add(DeliveryRewardPolicy.CreateGuaranteedCoinReward());
        return this with { Items = rewards };
    }
}

public static class DeliveryRewardPolicy
{
    public const int CoinRewardId = 7;
    public const int GuaranteedCoinAmount = 1000;

    public static LogicDeliveryReward CreateGuaranteedCoinReward() =>
        new(CoinRewardId, GuaranteedCoinAmount);

    public static LogicDeliveryItem Apply(LogicDeliveryItem item)
    {
        ArgumentNullException.ThrowIfNull(item);
        ArgumentNullException.ThrowIfNull(item.Items);
        return item.WithGuaranteedCoins();
    }

    public static IReadOnlyList<LogicDeliveryItem> ApplyToAll(
        IEnumerable<LogicDeliveryItem> items)
    {
        ArgumentNullException.ThrowIfNull(items);
        return items.Select(Apply).ToArray();
    }
}
