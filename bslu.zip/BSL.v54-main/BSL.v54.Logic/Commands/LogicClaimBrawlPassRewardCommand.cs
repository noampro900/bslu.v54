﻿using BSL.v54.Logic.Protocol;
using BSL.v54.Logic.Protocol.Laser.S;

namespace BSL.v54.Logic.Commands;

/// <summary>
/// LRBS-54 command 517. Decodes MilestoneID, Unk, BPSeason and LVL.
/// The temporary DB enforces premium-pass ownership, prevents duplicate payouts,
/// and credits the guaranteed Logic Delivery Item coin reward.
/// </summary>
public sealed class LogicClaimBrawlPassRewardCommand : ILogicCommand
{
    public int CommandType => 517;
    public string Name => "LogicClaimBrawlPassRewardCommand";
    public int MilestoneId { get; private set; }
    public int Unknown { get; private set; }
    public int BpSeason { get; private set; }
    public int Level { get; private set; }

    public void Decode(PiranhaMessage message)
    {
        // Common LogicCommand header from LRBS-54:
        // TickWhenGiven, ExecuteTick, ExecutorAccountID (two VInts).
        _ = message.ByteStream.ReadVInt();
        _ = message.ByteStream.ReadVInt();
        _ = message.ByteStream.ReadVInt();
        _ = message.ByteStream.ReadVInt();

        MilestoneId = message.ByteStream.ReadVInt();
        Unknown = message.ByteStream.ReadVInt();
        BpSeason = message.ByteStream.ReadVInt();
        Level = message.ByteStream.ReadVInt();
    }

    public void Execute(CommandContext context)
    {
        // Every Logic Delivery Item is guaranteed to contain exactly 1,000 coins.
        var deliveryItem = DeliveryRewardPolicy.Apply(
            new LogicDeliveryItem(100, Array.Empty<LogicDeliveryReward>()));
        var coinReward = deliveryItem.Items
            .Single(reward => reward.RewardId == DeliveryRewardPolicy.CoinRewardId);

        // MilestoneId identifies the Brawl Pass reward track (for example,
        // free and premium tracks). The guaranteed coin reward is applied to
        // every track; the database tracks claims independently per track.
        var ok = context.Database.TryClaimBrawlPassLevel(
            context.AccountId, BpSeason, MilestoneId, Level, coinReward.Amount, out var result);

        if (ok)
        {
            // Match Nerl's LogicClaimRankUpRewardCommand:
            // RewardTrackType = claimed track (9/10/12),
            // RewardForRank = 2 + claimed level,
            // BrawlPassSeason = requested season.
            context.Database.SetBrawlPassDeliveryState(
                context.AccountId,
                MilestoneId,
                checked(Level + 2),
                BpSeason);

            var player = context.Database.Get(context.AccountId);
            if (player is not null)
            {
                // LRBS sends AvailableServerCommandMessage (24111) carrying
                // server command 203. Do not immediately send OwnHomeData here:
                // it can replace the delivery animation/state just delivered.
                context.Messaging.Send(new AvailableServerCommandMessage(
                    new[] { deliveryItem },
                    player.RewardTrackType,
                    player.RewardForRank,
                    player.BrawlPassSeason));
            }
        }

        var balance = context.Database.Get(context.AccountId)?.Coins ?? 0;
        Console.WriteLine($"{Name}: account={context.AccountId}, milestone={MilestoneId}, " +
                          $"season={BpSeason}, level={Level}, success={ok}, " +
                          $"coins={balance}, result={result}");
    }
}
