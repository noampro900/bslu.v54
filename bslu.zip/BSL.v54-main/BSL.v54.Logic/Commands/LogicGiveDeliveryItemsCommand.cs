﻿using BSL.v54.Logic.Commands;
using BSL.v54.TitanEngine.DataS;
using BSL.v54.TitanEngine.DataS.HelpsLogic;

namespace BSL.v54.Logic.Commands;

/// <summary>
/// Server command 203: LogicGiveDeliveryItemsCommand.
/// Ported from the supplied LRBS-54 Python implementation.
/// </summary>
public static class LogicGiveDeliveryItemsCommand
{
    public const int CommandType = 203;

    public static void Encode(
        ByteStream stream,
        IReadOnlyList<LogicDeliveryItem> boxes,
        int rewardTrackType,
        int rewardForRank,
        int brawlPassSeason)
    {
        ArgumentNullException.ThrowIfNull(stream);
        ArgumentNullException.ThrowIfNull(boxes);

        // LogicGiveDeliveryItemsCommand payload.
        stream.WriteVInt(0);
        stream.WriteVInt(boxes.Count);

        foreach (var box in boxes)
        {
            stream.WriteVInt(box.Type);
            stream.WriteVInt(box.Items.Count);

            foreach (var reward in box.Items)
            {
                stream.WriteVInt(reward.Amount);

                // First reference slot: only class 16 is serialized here.
                WriteConditionalReference(stream, reward, 16);

                stream.WriteVInt(reward.RewardId);

                // The Python source has four reference slots, each with
                // its own accepted class IDs.
                WriteConditionalReference(stream, reward, 29);
                WriteConditionalReference(stream, reward, 52, 28);
                WriteConditionalReference(stream, reward, 23);

                stream.WriteVInt(0);
                stream.WriteVInt(0);
                stream.WriteVInt(0);
                stream.WriteVInt(0);
            }
        }

        stream.WriteBoolean(false);
        stream.WriteVInt(rewardTrackType);
        stream.WriteVInt(rewardForRank);
        stream.WriteVInt(brawlPassSeason);

        // LogicServerCommand -> LogicCommand common header.
        // LRBS-54 LogicCommand.encode writes 0, 0, and VLong(0, 0).
        stream.WriteVInt(0); // TickWhenGiven
        stream.WriteVInt(0); // ExecuteTick
        stream.WriteVInt(0); // ExecutorAccountID high
        stream.WriteVInt(0); // ExecutorAccountID low
    }

    private static void WriteConditionalReference(
        ByteStream stream,
        LogicDeliveryReward reward,
        params int[] acceptedClasses)
    {
        if (acceptedClasses.Contains(reward.DataClass))
            ByteStreamHelper.WriteDataReference(stream, reward.DataClass, reward.DataInstance);
        else
            ByteStreamHelper.WriteDataReference(stream, 0, 0);
    }
}
