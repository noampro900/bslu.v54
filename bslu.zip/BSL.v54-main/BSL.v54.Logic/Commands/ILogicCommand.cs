using BSL.v54.Logic.Protocol;

namespace BSL.v54.Logic.Commands;

/// <summary>
/// One decoded command inside client message 14102 (EndClientTurn).
/// Implementations must consume exactly the command's serialized fields.
/// </summary>
public interface ILogicCommand
{
    int CommandType { get; }
    string Name { get; }
    void Decode(PiranhaMessage message);
    void Execute(CommandContext context);
}
