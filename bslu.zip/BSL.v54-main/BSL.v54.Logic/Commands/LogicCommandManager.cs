using System.Collections.Frozen;
using BSL.v54.Logic.Protocol;

namespace BSL.v54.Logic.Commands;

/// <summary>
/// Registry for client logic commands. Add a decoder/handler for each command
/// after its exact v54 wire format and game-state behavior have been ported.
/// Unknown commands are rejected because their payload length is not self-delimiting.
/// </summary>
public static class LogicCommandManager
{
    private static readonly Dictionary<int, Func<ILogicCommand>> Mutable = new();
    private static FrozenDictionary<int, Func<ILogicCommand>>? _commands;

    static LogicCommandManager()
    {
        Register(560, () => new LogicBuyBrawlerCommand());
        Register(517, () => new LogicClaimBrawlPassRewardCommand());
        _commands = Mutable.ToFrozenDictionary();
    }

    public static void Register(int id, Func<ILogicCommand> factory)
    {
        Mutable[id] = factory;
        _commands = Mutable.ToFrozenDictionary();
    }

    public static bool TryCreate(int id, out ILogicCommand? command)
    {
        if (_commands is not null && _commands.TryGetValue(id, out var factory))
        {
            command = factory();
            return true;
        }
        command = null;
        return false;
    }

    public static IReadOnlyCollection<int> RegisteredCommandIds =>
        _commands?.Keys.ToArray() ?? Array.Empty<int>();
}
