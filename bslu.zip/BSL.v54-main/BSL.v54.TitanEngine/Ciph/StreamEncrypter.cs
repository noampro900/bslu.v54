﻿namespace BSL.v54.TitanEngine.Ciph;

public abstract class StreamEncrypter
{
    public abstract int GetEncryptionOverhead();
}