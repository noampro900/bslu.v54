﻿using BSL.v54.TitanEngine.NaCl;

namespace BSL.v54.TitanEngine.Pepp.Crypto;

public static class PepperKey
{
    static PepperKey()
    {
        ClientSecretKey = Convert.FromHexString("36abd74b2db5faa4d5a7977a1bc8be137ad7330efc934dfba36600ecd6871476");

        ServerPublicKey = Convert.FromHexString("c24121ef11b9873e6d2c163491d279afface121dfffc4cf94a7dec4373808e50");
    }

    public static byte[] ClientSecretKey { get; }
    public static byte[] ServerPublicKey { get; }
}