namespace BSL.v54.TitanEngine.Msg.Messages;

public abstract class TitanDisconnectedMessage
{
    public static int GetMessageType()
    {
        return 25892;
    }
}