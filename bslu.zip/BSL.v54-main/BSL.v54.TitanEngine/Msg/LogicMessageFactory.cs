﻿namespace BSL.v54.TitanEngine.Msg;

public abstract class LogicMessageFactory
{
    public abstract void Destruct();
}